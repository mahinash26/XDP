First run the loader file with the command
 >> sudo ./loader1
then enter load command to load the file
or unload to unload the file 
or exit to close


AFter that in a new terminal enter the following command:
 >> sudo ./stats1

this file will display the existing map and will allow you to update the map values by referencing them through the key (task 1)


As for the xdp_program.c; this file contains the map which has 10 enteries, following that it also contains the function to update the values in the map through the kernel(task 2)
